#!/usr/bin/env node
/**
 * MoltAgent Bot - Main Entry Point
 * 
 * Starts the heartbeat manager for automated task processing.
 * 
 * @version 1.0.0
 */

const fs = require('fs');
const path = require('path');

// Load integrations
const HeartbeatManager = require('./lib/integrations/heartbeat-manager');
const LLMRouter = require('./lib/llm-router');

// Configuration
const CONFIG = {
  nextcloud: {
    url: process.env.NC_URL || 'https://nx89136.your-storageshare.de',
    username: process.env.NC_USER || 'moltagent',
    password: process.env.NC_PASSWORD || 'uS694pDVvnbDpmQ'
  },
  ollama: {
    url: process.env.OLLAMA_URL || 'http://10.0.0.3:11434',
    model: process.env.OLLAMA_MODEL || 'deepseek-r1:8b'
  },
  deck: {
    boardId: parseInt(process.env.DECK_BOARD_ID) || 8
  },
  heartbeat: {
    intervalMs: parseInt(process.env.HEARTBEAT_INTERVAL) || 5 * 60 * 1000,  // 5 minutes
    quietHoursStart: parseInt(process.env.QUIET_START) || 23,  // 11 PM
    quietHoursEnd: parseInt(process.env.QUIET_END) || 7,       // 7 AM
    deckEnabled: true,
    caldavEnabled: true,
    maxTasksPerCycle: 3
  }
};

// Audit log to Nextcloud Files
async function auditLog(event, data) {
  const timestamp = new Date().toISOString();
  const logLine = JSON.stringify({ timestamp, event, ...data }) + '\n';
  
  // Console output
  console.log(`[AUDIT] ${event}:`, JSON.stringify(data).substring(0, 200));
  
  // Could also write to NC Files here via WebDAV
}

// User notification (placeholder - could send to NC Talk)
async function notifyUser(notification) {
  console.log(`[NOTIFY] ${notification.type}: ${notification.message}`);
  
  // TODO: Send to NC Talk when integrated
}

// Main startup
async function main() {
  console.log('');
  console.log('╔════════════════════════════════════════════════════════════════╗');
  console.log('║               MoltAgent Bot Starting...                        ║');
  console.log('╚════════════════════════════════════════════════════════════════╝');
  console.log('');
  console.log(`NC URL: ${CONFIG.nextcloud.url}`);
  console.log(`Ollama: ${CONFIG.ollama.url} (${CONFIG.ollama.model})`);
  console.log(`Deck Board ID: ${CONFIG.deck.boardId}`);
  console.log(`Heartbeat: every ${CONFIG.heartbeat.intervalMs / 1000}s`);
  console.log(`Quiet Hours: ${CONFIG.heartbeat.quietHoursStart}:00 - ${CONFIG.heartbeat.quietHoursEnd}:00`);
  console.log('');

  // Initialize LLM Router
  console.log('[INIT] Setting up LLM Router...');
  const llmRouter = new LLMRouter({
    ollama: CONFIG.ollama,
    auditLog
  });

  // Test Ollama connection
  const ollamaTest = await llmRouter.testConnection();
  if (ollamaTest.connected) {
    console.log(`[INIT] ✓ Ollama connected. Models: ${ollamaTest.models.join(', ')}`);
  } else {
    console.error(`[INIT] ✗ Ollama connection failed: ${ollamaTest.error}`);
    console.error('[INIT] Continuing anyway - will retry on heartbeat...');
  }

  // Initialize Heartbeat Manager
  console.log('[INIT] Setting up Heartbeat Manager...');
  const heartbeat = new HeartbeatManager({
    nextcloud: CONFIG.nextcloud,
    deck: CONFIG.deck,
    heartbeat: CONFIG.heartbeat,
    llmRouter,
    notifyUser,
    auditLog
  });

  // Handle shutdown gracefully
  let shuttingDown = false;
  
  async function shutdown(signal) {
    if (shuttingDown) return;
    shuttingDown = true;
    
    console.log('');
    console.log(`[SHUTDOWN] Received ${signal}, stopping gracefully...`);
    
    await heartbeat.stop();
    
    console.log('[SHUTDOWN] Heartbeat stopped.');
    console.log('[SHUTDOWN] Goodbye! 👋');
    process.exit(0);
  }

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));

  // Start the heartbeat
  console.log('[INIT] Starting heartbeat...');
  await heartbeat.start();

  console.log('');
  console.log('╔════════════════════════════════════════════════════════════════╗');
  console.log('║               MoltAgent Bot Running! 🚀                        ║');
  console.log('╚════════════════════════════════════════════════════════════════╝');
  console.log('');
  console.log('Press Ctrl+C to stop.');
  console.log('');

  // Keep process running
  // The heartbeat interval keeps the event loop alive
}

// Run
main().catch(err => {
  console.error('[FATAL]', err);
  process.exit(1);
});
